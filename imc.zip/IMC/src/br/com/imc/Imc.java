package br.com.imc;

//importa a classe Scanner
import java.util.Scanner;

public class Imc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instancia os objetos
		Scanner leia = new Scanner(System.in);
		Pessoa resultado = new Pessoa();
		
		//Declara��o de vari�veis
		float altura;
		float peso;
		
		System.out.println("Digite seu peso:");
	    peso = leia.nextFloat();
	    System.out.println("Digite sua altura:");
	    altura = leia.nextFloat();
	    
	    System.out.println("seu IMC � " + resultado.imc(peso, altura));
	}
}
