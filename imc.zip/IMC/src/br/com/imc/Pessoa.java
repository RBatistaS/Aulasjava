package br.com.imc;

public class Pessoa {
	public float imc(float peso, float altura) {
		return (peso / (altura * altura));
	}
}
   